function searchCars() {
    // Simulate API call to get car data based on user input
    const pickUpLocation = document.getElementById("pick-up-location").value;
    const pickUpDate = document.getElementById("pick-up-date").value;
          }
        //   function decideTrip() {
        //     const budget = document.getElementById("budget").value;
        //     const travelStyle = document.getElementById("travel-style").value;
        //     const travelTime = document.getElementById("travel-time").value;
          
        //     // Simple decision logic based on user input
        //     let suggestion;
        //     if (budget === "low" && travelStyle === "adventure") {
        //       suggestion = "Backpacking through Southeast Asia!";
        //   [Image of Backpacking through Southeast Asia]
        //     } else if (budget === "low" && travelStyle === "relaxation") {
        //       suggestion = "Camping in a national park";
        //   [Image of Camping in a national park]
        //     } else if (budget === "low" && travelStyle === "culture") {
        //       suggestion = "Visiting historical sites in your own city";
        //   [Image of Visiting historical sites in your own city]
        //     } else if (budget === "medium" && travelStyle === "adventure") {
        //       suggestion = "Hiking the Inca Trail in Peru";
        //   [Image of Hiking the Inca Trail in Peru]
        //     } else if (budget === "medium" && travelStyle === "relaxation") {
        //       suggestion = "Island hopping in Greece";
        //   [Image of Island hopping in Greece]
        //     } else if (budget === "medium" && travelStyle === "culture") {
        //       suggestion = "Attending a music festival in Europe";
        //   [Image of Attending a music festival in Europe]
        //     } else if (budget === "high" && travelStyle === "adventure") {
        //       suggestion = "Sc
        //     }}